NonCartestianReconstruction

A MATLAB reconstruction framework for non-Cartesian reconstruction. 

INSTALLATION
Run setup.m to add the Recon package to your MATLAB path.

USAGE
See Recon.Demo.Scripts.demo_recon.m